class Symbol {
    char character;
    int lineNumber, position;

    Symbol(char character, int lineNumber, int position) {
        this.character = character;
        this.lineNumber = lineNumber;
        this.position = position;
    }
}
