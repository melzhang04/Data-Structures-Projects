/**
 * Class containing methods that finds the greatest common denominator (GCD) if two nonzero numbers are provided.
 * @author Melisa Zhang
 * @version v1, 09-12-2022
 */
import java.util.*;
public class GCD {
    /**
     * Returns the greatest common denominator of two numbers using a while loop.
     * @param m  the first number user provides
     * @param n  the second number user provides
     * @return   the GCD
     */
    public static int iterativeGcd(int m, int n) {
        m = Math.abs(m);
        n = Math.abs(n);
        int temp = 0;
        int small = 0;
        int big = 0;
        if(m > n){
            small = n;
            big = m;
        }
        else{
            small = m;
            big = n;
        }
        while(small != 0){
            temp = small;
            small = big%small;
            big = temp;
        }
        return big;
    }
    /**
     * Returns the greatest common denominator of two numbers using recursion.
     * @param m  the first number user provides
     * @param n  the second number user provides
     * @return   the GCD
     */
    public static int recursiveGcd(int m, int n){
        m = Math.abs(m);
        n = Math.abs(n);
        int small = 0;
        int big = 0;
        int temp = 0;
        if(m > n){
            small = n;
            big = m;
        }
        else{
            small = m;
            big = n;
        }
        if(small!=0){
            temp = small;
            small = big%small;
            big = temp;
            return recursiveGcd(big,small);
        }
        return big;
    }
    /**
     * Checks if user input contains only 2 arguments that are nonzero numbers. Calls and prints iterativeGCD and recursiveGCD if conditions are met.
     * @param args command line arguments user inputs
     */
    public static void main(String[] args) {
        if(args.length != 2){
            System.out.println("Usage: java GCD <integer m> <integer n>");
            System.exit(1);
        }
            try{
                int m = Integer.parseInt(args[0]);
            }
            catch(NumberFormatException x){
                System.out.println("Error: The first argument is not a valid integer.");
                System.exit(1);
            }
            try{
                int m = Integer.parseInt(args[1]);
            }
            catch(NumberFormatException x){
                System.out.println("Error: The second argument is not a valid integer.");
                System.exit(1);
            }
        if(args.length == 2 && Integer.parseInt(args[0]) == 0 && Integer.parseInt(args[1]) == 0){
            System.out.println("gcd(0, 0) = undefined");
        }
        else if (args.length == 2){
            System.out.println("Iterative: gcd("+ args[0] + ", "+ args[1] + ") = " + iterativeGcd(Integer.parseInt(args[0]), Integer.parseInt(args[1])));
            System.out.println("Recursive: gcd("+ args[0] + ", "+ args[1] + ") = " + recursiveGcd(Integer.parseInt(args[0]), Integer.parseInt(args[1])));
        }
    }
}
