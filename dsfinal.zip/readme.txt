CommonWordFinder -- DS 3134 Final Project

Name: Melisa Zhang
UNI: mz2955
Date: 12/16/2022

Question: What data structure do you expect to have the best (fastest) performance? Which one do you expect to be the slowest? Do the results of timing your program’s execution match your expectations? If so, briefly explain the correlation. If not, what run times deviated and briefly explain why you think this is the case. 

I expect that the MyHashMap will have the best/fastest performance as it has constant time search, insertion, and deletion as compared to the Theta(log(n)) time complexion search, insertion, and deletion of BSTMap and AVLTreeMap. I expect that the AVLTreeMap will be the slowest as it has an Theta(log(n)) time complexity to search, insert, and delete from the tree and also requires to tree to be balanced. This means that the AVL tree would need to be checked each time an entry was added to the map; this would cost an additional Theta(log(n)), making BST slightly faster than AVL.

Average Program Execution Results for 5 Trials:
BST run time:	[0m1.634s, 0m1.123s, 0m1.154s, 0m1.103s, 0m1.105s] = 0m1.224s
AVL run time:	[0m1.526s, 0m1.479s, 0m1.307s, 0m1.192s, 0m1.260s] = 0m1.353s
Hash run time:	[0m1.334s, 0m1.023s, 0m1.120s, 0m1.051s, 0m0.997s] = 0m1.105s

The results of the timing for my program's execution matches my expectations. Since we are only really inserting into a map, and never deleting from it, hash has a Theta(1) time complexity for inserting into the map. This makes hash have a faster run time as it is the most efficient data structure out of the three in terms of time complexity of inserting. This will make hash faster than BST and AVL. Both AVL and BST have the same insertion time complexity of Theta(log(n)), but since after every insertion AVL has to check the balance while BST does not, AVL is slightly slower than BST as it has to do an additional Theta(log(n)) operation. The difference is only really apparent between BST and AVL when the data input size is large.
